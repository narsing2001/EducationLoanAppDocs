package com.educationloan.auth.service;

import com.educationloan.auth.entity.User;
import com.educationloan.auth.exception.UnauthorizedException;
import com.educationloan.auth.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
@Transactional(readOnly = true)
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    /**
     * Get user by email
     */
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UnauthorizedException("User not found"));
    }
    
    /**
     * Get user by username
     */
    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new UnauthorizedException("User not found"));
    }
    
    /**
     * Get user by ID
     */
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new UnauthorizedException("User not found"));
    }
    
    /**
     * Check if user is admin
     */
    public boolean isUserAdmin(Long userId) {
        User user = getUserById(userId);
        return user.getRoles().stream()
                .anyMatch(role -> role.getName().name().equals("ADMIN"));
    }
    
    /**
     * Check if user is employee
     */
    public boolean isUserEmployee(Long userId) {
        User user = getUserById(userId);
        return user.getRoles().stream()
                .anyMatch(role -> role.getName().name().equals("EMPLOYEE"));
    }
}