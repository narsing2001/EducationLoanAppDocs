package com.educationloan.auth.config;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

class JwtTokenProviderTest {
    
    private JwtTokenProvider jwtTokenProvider;
    private String testSecret = "testSecretKeyForEducationLoanApplicationWithJWTTokenAndMinimum256BitsForHS256Algorithm";
    
    @BeforeEach
    void setUp() {
        jwtTokenProvider = new JwtTokenProvider();
        jwtTokenProvider.jwtSecret = testSecret;
        jwtTokenProvider.jwtExpirationMs = 86400000;
        jwtTokenProvider.refreshTokenExpirationMs = 604800000;
        jwtTokenProvider.init();
    }
    
    @Test
    void testGenerateAccessToken() {
        Authentication authentication = new UsernamePasswordAuthenticationToken(
                "testuser", 
                null, 
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER"))
        );
        
        String token = jwtTokenProvider.generateAccessToken(authentication);
        assertNotNull(token);
        assertFalse(token.isEmpty());
    }
    
    @Test
    void testGenerateRefreshToken() {
        String token = jwtTokenProvider.generateRefreshToken("testuser");
        assertNotNull(token);
        assertFalse(token.isEmpty());
    }
    
    @Test
    void testValidateToken() {
        Authentication authentication = new UsernamePasswordAuthenticationToken(
                "testuser", 
                null, 
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER"))
        );
        
        String token = jwtTokenProvider.generateAccessToken(authentication);
        assertTrue(jwtTokenProvider.validateToken(token));
    }
    
    @Test
    void testGetUsernameFromToken() {
        Authentication authentication = new UsernamePasswordAuthenticationToken(
                "testuser", 
                null, 
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER"))
        );
        
        String token = jwtTokenProvider.generateAccessToken(authentication);
        String username = jwtTokenProvider.getUsernameFromToken(token);
        assertEquals("testuser", username);
    }
}