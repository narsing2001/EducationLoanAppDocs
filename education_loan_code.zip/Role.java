package com.educationloan.auth.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "roles")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Role {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false)
    @Enumerated(EnumType.STRING)
    private RoleEnum name;
    
    @Column(length = 500)
    private String description;
    
    public enum RoleEnum {
        USER("User role for loan applicants"),
        EMPLOYEE("Employee role for bank staff"),
        ADMIN("Admin role for system administrators");
        
        private final String description;
        
        RoleEnum(String description) {
            this.description = description;
        }
        
        public String getDescription() {
            return description;
        }
    }
}