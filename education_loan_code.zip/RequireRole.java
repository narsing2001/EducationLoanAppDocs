package com.educationloan.auth.annotation;

import java.lang.annotation.*;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface RequireRole {
    
    String[] roles() default {};
    
    boolean requireAll() default false;
}