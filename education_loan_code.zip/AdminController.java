package com.educationloan.admin.controller;

import com.educationloan.auth.entity.Role;
import com.educationloan.auth.entity.User;
import com.educationloan.auth.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@Slf4j
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:4200", "http://localhost:8080"})
public class AdminController {
    
    @Autowired
    private UserService userService;
    
    /**
     * Get all users - ADMIN only
     * GET /api/admin/users
     */
    @GetMapping("/users")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getAllUsers(Authentication authentication) {
        try {
            String adminName = authentication.getName();
            log.info("Admin: {} is fetching all users", adminName);
            return new ResponseEntity<>("All users data", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error fetching users: {}", e.getMessage());
            return new ResponseEntity<>("Error fetching users", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Get user by ID - ADMIN only
     * GET /api/admin/users/{userId}
     */
    @GetMapping("/users/{userId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> getUserById(@PathVariable Long userId,
                                        Authentication authentication) {
        try {
            String adminName = authentication.getName();
            User user = userService.getUserById(userId);
            log.info("Admin: {} is fetching user: {}", adminName, user.getEmail());
            return new ResponseEntity<>(user, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error fetching user: {}", e.getMessage());
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
        }
    }
    
    /**
     * Assign role to user - ADMIN only
     * POST /api/admin/users/{userId}/assign-role
     */
    @PostMapping("/users/{userId}/assign-role")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> assignRoleToUser(@PathVariable Long userId,
                                             @RequestParam String roleName,
                                             Authentication authentication) {
        try {
            String adminName = authentication.getName();
            Role.RoleEnum role = Role.RoleEnum.valueOf(roleName);
            userService.assignRoleToUser(userId, role);
            log.info("Admin: {} assigned role: {} to user: {}", adminName, roleName, userId);
            return new ResponseEntity<>("Role assigned successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error assigning role: {}", e.getMessage());
            return new ResponseEntity<>("Error assigning role", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Remove role from user - ADMIN only
     * DELETE /api/admin/users/{userId}/remove-role
     */
    @DeleteMapping("/users/{userId}/remove-role")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> removeRoleFromUser(@PathVariable Long userId,
                                               @RequestParam String roleName,
                                               Authentication authentication) {
        try {
            String adminName = authentication.getName();
            Role.RoleEnum role = Role.RoleEnum.valueOf(roleName);
            userService.removeRoleFromUser(userId, role);
            log.info("Admin: {} removed role: {} from user: {}", adminName, roleName, userId);
            return new ResponseEntity<>("Role removed successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error removing role: {}", e.getMessage());
            return new ResponseEntity<>("Error removing role", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Activate user - ADMIN only
     * POST /api/admin/users/{userId}/activate
     */
    @PostMapping("/users/{userId}/activate")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> activateUser(@PathVariable Long userId,
                                         Authentication authentication) {
        try {
            String adminName = authentication.getName();
            userService.activateUser(userId);
            log.info("Admin: {} activated user: {}", adminName, userId);
            return new ResponseEntity<>("User activated successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error activating user: {}", e.getMessage());
            return new ResponseEntity<>("Error activating user", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Deactivate user - ADMIN only
     * POST /api/admin/users/{userId}/deactivate
     */
    @PostMapping("/users/{userId}/deactivate")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deactivateUser(@PathVariable Long userId,
                                           Authentication authentication) {
        try {
            String adminName = authentication.getName();
            userService.deactivateUser(userId);
            log.info("Admin: {} deactivated user: {}", adminName, userId);
            return new ResponseEntity<>("User deactivated successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error deactivating user: {}", e.getMessage());
            return new ResponseEntity<>("Error deactivating user", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}