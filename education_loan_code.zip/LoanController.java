package com.educationloan.loan.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/loans")
@Slf4j
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:4200", "http://localhost:8080"})
public class LoanController {
    
    /**
     * Get all loans - USER, EMPLOYEE, ADMIN
     * GET /api/loans
     */
    @GetMapping
    @PreAuthorize("hasAnyRole('USER', 'EMPLOYEE', 'ADMIN')")
    public ResponseEntity<?> getAllLoans(Authentication authentication) {
        try {
            String username = authentication.getName();
            String roles = authentication.getAuthorities().toString();
            
            log.info("User: {} with roles: {} is fetching loans", username, roles);
            
            if (authentication.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
                return new ResponseEntity<>("Admin viewing all loans", HttpStatus.OK);
            } else if (authentication.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ROLE_EMPLOYEE"))) {
                return new ResponseEntity<>("Employee viewing assigned loans", HttpStatus.OK);
            } else {
                return new ResponseEntity<>("User viewing their own loans", HttpStatus.OK);
            }
        } catch (Exception e) {
            log.error("Error fetching loans: {}", e.getMessage());
            return new ResponseEntity<>("Error fetching loans", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Create loan - USER, EMPLOYEE, ADMIN
     * POST /api/loans
     */
    @PostMapping
    @PreAuthorize("hasAnyRole('USER', 'EMPLOYEE', 'ADMIN')")
    public ResponseEntity<?> createLoan(@RequestBody Object loanRequest, 
                                        Authentication authentication) {
        try {
            String username = authentication.getName();
            log.info("Loan application created by: {}", username);
            return new ResponseEntity<>("Loan application created", HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("Error creating loan: {}", e.getMessage());
            return new ResponseEntity<>("Error creating loan", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Get loan by ID - USER, EMPLOYEE, ADMIN
     * GET /api/loans/{loanId}
     */
    @GetMapping("/{loanId}")
    @PreAuthorize("hasAnyRole('USER', 'EMPLOYEE', 'ADMIN')")
    public ResponseEntity<?> getLoanById(@PathVariable Long loanId, 
                                         Authentication authentication) {
        try {
            String username = authentication.getName();
            log.info("User: {} is fetching loan: {}", username, loanId);
            return new ResponseEntity<>("Loan details", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error fetching loan: {}", e.getMessage());
            return new ResponseEntity<>("Loan not found", HttpStatus.NOT_FOUND);
        }
    }
    
    /**
     * Update loan - EMPLOYEE, ADMIN
     * PUT /api/loans/{loanId}
     */
    @PutMapping("/{loanId}")
    @PreAuthorize("hasAnyRole('EMPLOYEE', 'ADMIN')")
    public ResponseEntity<?> updateLoan(@PathVariable Long loanId, 
                                        @RequestBody Object loanRequest,
                                        Authentication authentication) {
        try {
            String username = authentication.getName();
            log.info("User: {} is updating loan: {}", username, loanId);
            return new ResponseEntity<>("Loan updated successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error updating loan: {}", e.getMessage());
            return new ResponseEntity<>("Error updating loan", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Approve loan - ADMIN only
     * POST /api/loans/{loanId}/approve
     */
    @PostMapping("/{loanId}/approve")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> approveLoan(@PathVariable Long loanId,
                                        Authentication authentication) {
        try {
            String username = authentication.getName();
            log.info("Admin: {} is approving loan: {}", username, loanId);
            return new ResponseEntity<>("Loan approved successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error approving loan: {}", e.getMessage());
            return new ResponseEntity<>("Error approving loan", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Reject loan - EMPLOYEE, ADMIN
     * POST /api/loans/{loanId}/reject
     */
    @PostMapping("/{loanId}/reject")
    @PreAuthorize("hasAnyRole('EMPLOYEE', 'ADMIN')")
    public ResponseEntity<?> rejectLoan(@PathVariable Long loanId,
                                        @RequestBody Object rejectionReason,
                                        Authentication authentication) {
        try {
            String username = authentication.getName();
            log.info("User: {} is rejecting loan: {}", username, loanId);
            return new ResponseEntity<>("Loan rejected successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error rejecting loan: {}", e.getMessage());
            return new ResponseEntity<>("Error rejecting loan", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Delete loan - ADMIN only
     * DELETE /api/loans/{loanId}
     */
    @DeleteMapping("/{loanId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> deleteLoan(@PathVariable Long loanId,
                                        Authentication authentication) {
        try {
            String username = authentication.getName();
            log.info("Admin: {} is deleting loan: {}", username, loanId);
            return new ResponseEntity<>("Loan deleted successfully", HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error deleting loan: {}", e.getMessage());
            return new ResponseEntity<>("Error deleting loan", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}