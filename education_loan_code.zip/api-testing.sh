#!/bin/bash

# 1. Register User
echo "=== Registering User ==="
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john_doe",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "password": "password123",
    "confirmPassword": "password123"
  }'

# 2. Login User
echo -e "\n\n=== Login User ==="
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "password123"
  }'

# 3. Get Loans (with JWT token)
echo -e "\n\n=== Get Loans ==="
curl -X GET http://localhost:8080/api/loans \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN_HERE"

# 4. Create Loan
echo -e "\n\n=== Create Loan ==="
curl -X POST http://localhost:8080/api/loans \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN_HERE" \
  -d '{
    "amount": 500000,
    "tenure": 5,
    "institution": "XYZ University"
  }'

# 5. Approve Loan (Admin only)
echo -e "\n\n=== Approve Loan (Admin) ==="
curl -X POST http://localhost:8080/api/loans/1/approve \
  -H "Authorization: Bearer ADMIN_TOKEN_HERE"

# 6. Refresh Token
echo -e "\n\n=== Refresh Token ==="
curl -X POST http://localhost:8080/api/auth/refresh-token \
  -H "Content-Type: application/json" \
  -d '{
    "refreshToken": "YOUR_REFRESH_TOKEN_HERE"
  }'