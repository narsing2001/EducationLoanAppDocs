#!/bin/bash

# Step 1: Navigate to project directory
cd education-loan-auth-service

# Step 2: Clean and build
mvn clean install -DskipTests

# Step 3: Run the application
mvn spring-boot:run

# Or run as JAR
# java -jar target/education-loan-auth-service-1.0.0.jar