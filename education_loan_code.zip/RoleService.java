package com.educationloan.auth.service;

import com.educationloan.auth.entity.Role;
import com.educationloan.auth.repository.RoleRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
@Transactional
public class RoleService {
    
    @Autowired
    private RoleRepository roleRepository;
    
    /**
     * Get role by name
     */
    public Optional<Role> getRoleByName(Role.RoleEnum name) {
        return roleRepository.findByName(name);
    }
    
    /**
     * Get all roles
     */
    public List<Role> getAllRoles() {
        return roleRepository.findAll();
    }
    
    /**
     * Create or get role
     */
    public Role createOrGetRole(Role.RoleEnum name) {
        Optional<Role> existingRole = roleRepository.findByName(name);
        if (existingRole.isPresent()) {
            return existingRole.get();
        }
        
        Role newRole = Role.builder()
                .name(name)
                .description(name.getDescription())
                .build();
        return roleRepository.save(newRole);
    }
}