package com.educationloan.auth.dto;

import lombok.*;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ErrorResponse {
    
    private int statusCode;
    private String message;
    private String error;
    private LocalDateTime timestamp;
    private String path;
}