package com.educationloan.auth.controller;

import com.educationloan.auth.dto.*;
import com.educationloan.auth.service.AuthService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@Slf4j
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:4200", "http://localhost:8080"})
public class AuthController {
    
    @Autowired
    private AuthService authService;
    
    /**
     * Register endpoint - POST /api/auth/register
     */
    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest registerRequest) {
        try {
            log.info("Registration request for email: {}", registerRequest.getEmail());
            LoginResponse response = authService.register(registerRequest);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            ErrorResponse errorResponse = ErrorResponse.builder()
                    .statusCode(HttpStatus.BAD_REQUEST.value())
                    .message(e.getMessage())
                    .error("Registration Error")
                    .build();
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            log.error("Registration error: {}", e.getMessage());
            ErrorResponse errorResponse = ErrorResponse.builder()
                    .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                    .message("Registration failed")
                    .error(e.getMessage())
                    .build();
            return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Login endpoint - POST /api/auth/login
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest loginRequest) {
        try {
            log.info("Login request for email: {}", loginRequest.getEmail());
            LoginResponse response = authService.login(loginRequest);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Login error: {}", e.getMessage());
            ErrorResponse errorResponse = ErrorResponse.builder()
                    .statusCode(HttpStatus.UNAUTHORIZED.value())
                    .message("Invalid email or password")
                    .error(e.getMessage())
                    .build();
            return new ResponseEntity<>(errorResponse, HttpStatus.UNAUTHORIZED);
        }
    }
    
    /**
     * Refresh Token endpoint - POST /api/auth/refresh-token
     */
    @PostMapping("/refresh-token")
    public ResponseEntity<?> refreshToken(@RequestBody JwtTokenResponse tokenRequest) {
        try {
            log.info("Token refresh request");
            LoginResponse response = authService.refreshToken(tokenRequest.getRefreshToken());
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Token refresh error: {}", e.getMessage());
            ErrorResponse errorResponse = ErrorResponse.builder()
                    .statusCode(HttpStatus.UNAUTHORIZED.value())
                    .message("Token refresh failed")
                    .error(e.getMessage())
                    .build();
            return new ResponseEntity<>(errorResponse, HttpStatus.UNAUTHORIZED);
        }
    }
    
    /**
     * Validate Token endpoint - GET /api/auth/validate
     */
    @GetMapping("/validate")
    public ResponseEntity<?> validateToken() {
        return new ResponseEntity<>(
                MessageResponse.builder()
                        .message("Token is valid")
                        .success(true)
                        .build(), 
                HttpStatus.OK
        );
    }
    
    /**
     * Logout endpoint - POST /api/auth/logout
     */
    @PostMapping("/logout")
    public ResponseEntity<?> logout(@RequestHeader(value = "Authorization", required = false) String token) {
        try {
            log.info("Logout request");
            authService.logout("user");
            return new ResponseEntity<>(
                    MessageResponse.builder()
                            .message("Logged out successfully")
                            .success(true)
                            .build(), 
                    HttpStatus.OK
            );
        } catch (Exception e) {
            ErrorResponse errorResponse = ErrorResponse.builder()
                    .statusCode(HttpStatus.BAD_REQUEST.value())
                    .message("Logout failed")
                    .error(e.getMessage())
                    .build();
            return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
        }
    }
    
    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<?> health() {
        return new ResponseEntity<>(
                MessageResponse.builder()
                        .message("Auth service is running")
                        .success(true)
                        .build(),
                HttpStatus.OK
        );
    }
}