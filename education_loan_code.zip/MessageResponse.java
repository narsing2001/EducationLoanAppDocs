package com.educationloan.auth.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MessageResponse {
    
    private String message;
    private Boolean success;
    private Object data;
}