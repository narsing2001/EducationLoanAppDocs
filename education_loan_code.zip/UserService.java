package com.educationloan.auth.service;

import com.educationloan.auth.entity.Role;
import com.educationloan.auth.entity.User;
import com.educationloan.auth.exception.UnauthorizedException;
import com.educationloan.auth.repository.RoleRepository;
import com.educationloan.auth.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Service
@Slf4j
@Transactional
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private RoleRepository roleRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    /**
     * Get user by email
     */
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UnauthorizedException("User not found"));
    }
    
    /**
     * Get user by username
     */
    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new UnauthorizedException("User not found"));
    }
    
    /**
     * Get user by ID
     */
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new UnauthorizedException("User not found"));
    }
    
    /**
     * Assign role to user
     */
    public void assignRoleToUser(Long userId, Role.RoleEnum roleName) {
        User user = getUserById(userId);
        Role role = roleRepository.findByName(roleName)
                .orElseThrow(() -> new RuntimeException("Role not found"));
        
        if (!user.getRoles().contains(role)) {
            user.getRoles().add(role);
            userRepository.save(user);
            log.info("Role {} assigned to user: {}", roleName, user.getEmail());
        }
    }
    
    /**
     * Remove role from user
     */
    public void removeRoleFromUser(Long userId, Role.RoleEnum roleName) {
        User user = getUserById(userId);
        Role role = roleRepository.findByName(roleName)
                .orElseThrow(() -> new RuntimeException("Role not found"));
        
        user.getRoles().remove(role);
        userRepository.save(user);
        log.info("Role {} removed from user: {}", roleName, user.getEmail());
    }
    
    /**
     * Check if user is admin
     */
    public boolean isUserAdmin(Long userId) {
        User user = getUserById(userId);
        return user.getRoles().stream()
                .anyMatch(role -> role.getName() == Role.RoleEnum.ADMIN);
    }
    
    /**
     * Check if user is employee
     */
    public boolean isUserEmployee(Long userId) {
        User user = getUserById(userId);
        return user.getRoles().stream()
                .anyMatch(role -> role.getName() == Role.RoleEnum.EMPLOYEE);
    }
    
    /**
     * Check if user has specific role
     */
    public boolean hasRole(Long userId, Role.RoleEnum roleName) {
        User user = getUserById(userId);
        return user.getRoles().stream()
                .anyMatch(role -> role.getName() == roleName);
    }
    
    /**
     * Activate user
     */
    public void activateUser(Long userId) {
        User user = getUserById(userId);
        user.setIsActive(true);
        userRepository.save(user);
        log.info("User activated: {}", user.getEmail());
    }
    
    /**
     * Deactivate user
     */
    public void deactivateUser(Long userId) {
        User user = getUserById(userId);
        user.setIsActive(false);
        userRepository.save(user);
        log.info("User deactivated: {}", user.getEmail());
    }
}