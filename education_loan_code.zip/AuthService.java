package com.educationloan.auth.service;

import com.educationloan.auth.config.JwtTokenProvider;
import com.educationloan.auth.dto.LoginRequest;
import com.educationloan.auth.dto.LoginResponse;
import com.educationloan.auth.dto.RegisterRequest;
import com.educationloan.auth.entity.Role;
import com.educationloan.auth.entity.User;
import com.educationloan.auth.exception.UnauthorizedException;
import com.educationloan.auth.repository.RoleRepository;
import com.educationloan.auth.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.HashSet;
import java.util.stream.Collectors;

@Service
@Slf4j
@Transactional
public class AuthService {
    
    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private RoleRepository roleRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private JwtTokenProvider jwtTokenProvider;
    
    /**
     * Register new user with default USER role
     */
    public LoginResponse register(RegisterRequest registerRequest) {
        if (!registerRequest.getPassword().equals(registerRequest.getConfirmPassword())) {
            throw new IllegalArgumentException("Passwords do not match");
        }
        
        if (userRepository.existsByEmail(registerRequest.getEmail())) {
            throw new IllegalArgumentException("Email is already registered");
        }
        
        if (userRepository.existsByUsername(registerRequest.getUsername())) {
            throw new IllegalArgumentException("Username is already taken");
        }
        
        User user = User.builder()
                .username(registerRequest.getUsername())
                .email(registerRequest.getEmail())
                .firstName(registerRequest.getFirstName())
                .lastName(registerRequest.getLastName())
                .password(passwordEncoder.encode(registerRequest.getPassword()))
                .isActive(true)
                .isEmailVerified(false)
                .build();
        
        Role userRole = roleRepository.findByName(Role.RoleEnum.USER)
                .orElseThrow(() -> new RuntimeException("USER role not found"));
        user.setRoles(new HashSet<>(Collections.singletonList(userRole)));
        
        User savedUser = userRepository.save(user);
        log.info("User registered successfully: {}", savedUser.getEmail());
        
        return generateLoginResponse(savedUser, null, null);
    }
    
    /**
     * Login user with email and password
     */
    public LoginResponse login(LoginRequest loginRequest) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            loginRequest.getEmail(),
                            loginRequest.getPassword()
                    )
            );
            
            User user = userRepository.findByEmail(loginRequest.getEmail())
                    .orElseThrow(() -> new UnauthorizedException("Invalid credentials"));
            
            if (!user.getIsActive()) {
                throw new UnauthorizedException("User account is inactive");
            }
            
            String accessToken = jwtTokenProvider.generateAccessToken(authentication);
            String refreshToken = jwtTokenProvider.generateRefreshToken(user.getUsername());
            
            log.info("User logged in successfully: {}", user.getEmail());
            
            return generateLoginResponse(user, accessToken, refreshToken);
            
        } catch (AuthenticationException e) {
            log.error("Login failed for email: {}", loginRequest.getEmail());
            throw new UnauthorizedException("Invalid email or password");
        }
    }
    
    /**
     * Refresh access token using refresh token
     */
    public LoginResponse refreshToken(String refreshToken) {
        if (!jwtTokenProvider.validateToken(refreshToken)) {
            throw new UnauthorizedException("Invalid or expired refresh token");
        }
        
        String username = jwtTokenProvider.getUsernameFromToken(refreshToken);
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new UnauthorizedException("User not found"));
        
        UsernamePasswordAuthenticationToken auth = 
                new UsernamePasswordAuthenticationToken(username, null);
        
        String newAccessToken = jwtTokenProvider.generateAccessToken(auth);
        String newRefreshToken = jwtTokenProvider.generateRefreshToken(username);
        
        log.info("Token refreshed for user: {}", username);
        
        return generateLoginResponse(user, newAccessToken, newRefreshToken);
    }
    
    /**
     * Logout user
     */
    public void logout(String username) {
        log.info("User logged out: {}", username);
    }
    
    /**
     * Generate login response
     */
    private LoginResponse generateLoginResponse(User user, String accessToken, String refreshToken) {
        long expirationTime = 86400000;
        
        return LoginResponse.builder()
                .userId(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .tokenType("Bearer")
                .expiresIn(expirationTime / 1000)
                .roles(user.getRoles().stream()
                        .map(role -> role.getName().name())
                        .collect(Collectors.toSet()))
                .build();
    }
}