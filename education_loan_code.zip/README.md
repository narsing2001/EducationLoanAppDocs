# Education Loan Authentication & Authorization Service

Complete Spring Boot JWT authentication and authorization service for Education Loan Application with role-based access control.

## Features

✅ JWT Token-based Authentication  
✅ Role-Based Authorization (USER, EMPLOYEE, ADMIN)  
✅ Secure Password Encryption (BCrypt)  
✅ Refresh Token Support  
✅ CORS Configuration  
✅ Input Validation  
✅ Global Exception Handling  
✅ Role Assignment Management  
✅ User Activation/Deactivation  
✅ Production-Ready Code  

## Roles

- **USER**: Loan applicants who can apply for loans
- **EMPLOYEE**: Bank staff who can view and process loans
- **ADMIN**: System administrators with full control

## API Endpoints

### Authentication Endpoints

#### 1. Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "username": "john_doe",
  "email": "john@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "password": "password123",
  "confirmPassword": "password123"
}
```

**Response:**
```json
{
  "userId": 1,
  "username": "john_doe",
  "email": "john@example.com",
  "firstName": "John",
  "lastName": "Doe",
  "accessToken": "eyJhbGciOiJIUzUxMiJ9...",
  "refreshToken": "eyJhbGciOiJIUzUxMiJ9...",
  "tokenType": "Bearer",
  "expiresIn": 86400,
  "roles": ["USER"]
}
```

#### 2. Login User
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}
```

#### 3. Refresh Token
```http
POST /api/auth/refresh-token
Content-Type: application/json

{
  "refreshToken": "eyJhbGciOiJIUzUxMiJ9..."
}
```

#### 4. Validate Token
```http
GET /api/auth/validate
Authorization: Bearer eyJhbGciOiJIUzUxMiJ9...
```

#### 5. Logout
```http
POST /api/auth/logout
Authorization: Bearer eyJhbGciOiJIUzUxMiJ9...
```

### Loan Endpoints

#### 1. Get All Loans (USER, EMPLOYEE, ADMIN)
```http
GET /api/loans
Authorization: Bearer {accessToken}
```

#### 2. Create Loan (USER, EMPLOYEE, ADMIN)
```http
POST /api/loans
Authorization: Bearer {accessToken}
Content-Type: application/json

{
  "amount": 500000,
  "tenure": 5,
  "institution": "XYZ University"
}
```

#### 3. Get Loan by ID (USER, EMPLOYEE, ADMIN)
```http
GET /api/loans/{loanId}
Authorization: Bearer {accessToken}
```

#### 4. Update Loan (EMPLOYEE, ADMIN)
```http
PUT /api/loans/{loanId}
Authorization: Bearer {accessToken}
Content-Type: application/json
```

#### 5. Approve Loan (ADMIN)
```http
POST /api/loans/{loanId}/approve
Authorization: Bearer {adminToken}
```

#### 6. Reject Loan (EMPLOYEE, ADMIN)
```http
POST /api/loans/{loanId}/reject
Authorization: Bearer {accessToken}
Content-Type: application/json

{
  "reason": "Incomplete documents"
}
```

#### 7. Delete Loan (ADMIN)
```http
DELETE /api/loans/{loanId}
Authorization: Bearer {adminToken}
```

### Admin Endpoints

#### 1. Get All Users (ADMIN)
```http
GET /api/admin/users
Authorization: Bearer {adminToken}
```

#### 2. Get User by ID (ADMIN)
```http
GET /api/admin/users/{userId}
Authorization: Bearer {adminToken}
```

#### 3. Assign Role to User (ADMIN)
```http
POST /api/admin/users/{userId}/assign-role?roleName=EMPLOYEE
Authorization: Bearer {adminToken}
```

#### 4. Remove Role from User (ADMIN)
```http
DELETE /api/admin/users/{userId}/remove-role?roleName=EMPLOYEE
Authorization: Bearer {adminToken}
```

#### 5. Activate User (ADMIN)
```http
POST /api/admin/users/{userId}/activate
Authorization: Bearer {adminToken}
```

#### 6. Deactivate User (ADMIN)
```http
POST /api/admin/users/{userId}/deactivate
Authorization: Bearer {adminToken}
```

## Setup Instructions

### Prerequisites
- Java 17 or higher
- MySQL 8.0 or higher
- Maven 3.6+

### Installation Steps

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/education-loan-auth-service.git
cd education-loan-auth-service
```

2. **Create MySQL Database**
```bash
mysql -u root -p < schema.sql
mysql -u root -p education_loan_db < data.sql
```

3. **Update application.properties**
```properties
spring.datasource.username=your_mysql_username
spring.datasource.password=your_mysql_password
app.jwt.secret=your_secret_key_minimum_256_bits
```

4. **Build the project**
```bash
mvn clean install
```

5. **Run the application**
```bash
mvn spring-boot:run
```

Or run as JAR:
```bash
java -jar target/education-loan-auth-service-1.0.0.jar
```

The application will start on http://localhost:8080

## Testing with cURL

### Register a new user
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john_doe",
    "email": "john@example.com",
    "firstName": "John",
    "lastName": "Doe",
    "password": "password123",
    "confirmPassword": "password123"
  }'
```

### Login
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "password123"
  }'
```

### Access Protected Endpoint
```bash
curl -X GET http://localhost:8080/api/loans \
  -H "Authorization: Bearer {accessToken}"
```

## Default Admin Credentials

- **Email**: admin@educationloan.com
- **Password**: admin123
- **Role**: ADMIN

## JWT Token Structure

Header:
```json
{
  "alg": "HS512",
  "typ": "JWT"
}
```

Payload:
```json
{
  "sub": "username",
  "roles": "ROLE_USER,ROLE_EMPLOYEE",
  "iat": 1672531200,
  "exp": 1672617600
}
```

## Security Features

- ✅ Password encryption using BCrypt
- ✅ JWT token-based stateless authentication
- ✅ CORS enabled for frontend integration
- ✅ Role-based authorization with @PreAuthorize
- ✅ Input validation with Jakarta Bean Validation
- ✅ Global exception handling
- ✅ Secure token refresh mechanism
- ✅ Session-less architecture

## Configuration

### JWT Settings (application.properties)
```properties
app.jwt.secret=your_256_bit_secret_key
app.jwt.expiration=86400000 # 24 hours in milliseconds
app.jwt.refresh-expiration=604800000 # 7 days in milliseconds
```

### Database Settings
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/education_loan_db
spring.datasource.username=root
spring.datasource.password=your_password
```

### CORS Settings (CorsConfig.java)
```java
configuration.setAllowedOrigins(Arrays.asList(
    "http://localhost:3000",
    "http://localhost:4200"
));
```

## Project Structure

```
education-loan-auth-service/
├── src/
│   ├── main/
│   │   ├── java/com/educationloan/
│   │   │   ├── auth/
│   │   │   │   ├── config/
│   │   │   │   ├── controller/
│   │   │   │   ├── service/
│   │   │   │   ├── repository/
│   │   │   │   ├── entity/
│   │   │   │   ├── dto/
│   │   │   │   ├── exception/
│   │   │   │   ├── annotation/
│   │   │   │   └── constant/
│   │   │   ├── loan/
│   │   │   ├── admin/
│   │   │   └── Application.java
│   │   └── resources/
│   │       ├── application.properties
│   │       ├── schema.sql
│   │       └── data.sql
│   └── test/
└── pom.xml
```

## Error Handling

The application provides consistent error responses:

```json
{
  "statusCode": 401,
  "message": "Invalid email or password",
  "error": "Unauthorized",
  "timestamp": "2024-01-15T10:30:00",
  "path": "/api/auth/login"
}
```

## Common HTTP Status Codes

- `200 OK` - Request successful
- `201 Created` - Resource created successfully
- `400 Bad Request` - Invalid input
- `401 Unauthorized` - Authentication failed
- `403 Forbidden` - Access denied
- `404 Not Found` - Resource not found
- `500 Internal Server Error` - Server error

## Development Notes

1. **Adding New Endpoints with Role Protection**
```java
@PostMapping
@PreAuthorize("hasRole('ADMIN')")
public ResponseEntity<?> createEntity() {
    // Implementation
}
```

2. **Checking User Roles Programmatically**
```java
authentication.getAuthorities()
    .stream()
    .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))
```

3. **Getting Current User**
```java
String username = authentication.getName();
User user = userService.getUserByEmail(username);
```

## License

This project is licensed under the MIT License - see LICENSE file for details.

## Support

For issues and questions, please create an issue in the repository or contact the development team.

## Contributors

- Your Name (your.email@example.com)

---

**Last Updated**: January 2024  
**Version**: 1.0.0