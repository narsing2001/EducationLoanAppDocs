# 1. Clone or create project
# 2. Navigate to project directory
cd education-loan-auth-service

# 3. Build the project
mvn clean install

# 4. Run the application
mvn spring-boot:run

# Or run as JAR
java -jar target/education-loan-auth-service-1.0.0.jar