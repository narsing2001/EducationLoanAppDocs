package com.educationloan.auth.constant;

public class RoleConstant {
    
    public static final String ROLE_USER = "USER";
    public static final String ROLE_EMPLOYEE = "EMPLOYEE";
    public static final String ROLE_ADMIN = "ADMIN";
    
    public static final String ROLE_PREFIX = "ROLE_";
    public static final String ROLE_USER_FULL = ROLE_PREFIX + ROLE_USER;
    public static final String ROLE_EMPLOYEE_FULL = ROLE_PREFIX + ROLE_EMPLOYEE;
    public static final String ROLE_ADMIN_FULL = ROLE_PREFIX + ROLE_ADMIN;
}