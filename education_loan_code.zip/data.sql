-- Insert Default Roles
INSERT IGNORE INTO roles (id, name, description) VALUES 
(1, 'USER', 'User role for loan applicants'),
(2, 'EMPLOYEE', 'Employee role for bank staff'),
(3, 'ADMIN', 'Admin role for system administrators');

-- Insert Sample Admin User (password: admin123)
INSERT IGNORE INTO users (id, username, email, password, first_name, last_name, is_active, is_email_verified) VALUES 
(1, 'admin', 'admin@educationloan.com', '$2a$10$slYQmyNdGzin7olVN3/p2OPST9/PgBkqquzi.Ss7KIUgO2t0jWMUe', 'Admin', 'User', TRUE, TRUE);

-- Assign Admin Role to Admin User
INSERT IGNORE INTO user_roles (user_id, role_id) VALUES 
(1, 3);